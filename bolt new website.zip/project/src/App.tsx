import { Sparkles, PartyPopper, Trophy } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-400 via-pink-500 to-purple-600 flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 left-10 animate-bounce">
          <Sparkles className="w-12 h-12 text-yellow-300 opacity-70" />
        </div>
        <div className="absolute top-20 right-20 animate-bounce delay-100">
          <PartyPopper className="w-16 h-16 text-pink-300 opacity-70" />
        </div>
        <div className="absolute bottom-20 left-20 animate-bounce delay-200">
          <Trophy className="w-14 h-14 text-yellow-300 opacity-70" />
        </div>
        <div className="absolute bottom-10 right-10 animate-bounce delay-300">
          <Sparkles className="w-10 h-10 text-white opacity-70" />
        </div>
        <div className="absolute top-1/2 left-1/4 animate-pulse">
          <PartyPopper className="w-8 h-8 text-yellow-200 opacity-50" />
        </div>
        <div className="absolute top-1/3 right-1/3 animate-pulse delay-150">
          <Sparkles className="w-10 h-10 text-pink-200 opacity-50" />
        </div>
      </div>

      <div className="relative z-10 text-center px-8">
        <div className="mb-8 flex justify-center gap-4">
          <PartyPopper className="w-16 h-16 text-yellow-300 animate-bounce" />
          <Trophy className="w-20 h-20 text-yellow-200" />
          <PartyPopper className="w-16 h-16 text-yellow-300 animate-bounce" />
        </div>

        <h1 className="text-6xl md:text-8xl font-black text-white mb-6 drop-shadow-2xl tracking-tight animate-pulse">
          TRW AI AUTOMATION
        </h1>

        <div className="bg-white/20 backdrop-blur-lg rounded-3xl p-8 md:p-12 shadow-2xl border-4 border-white/40 mb-8">
          <p className="text-4xl md:text-6xl font-bold text-white mb-4">
            DAILY PUZZLE COMPLETE
          </p>
          <div className="inline-block bg-gradient-to-r from-yellow-300 to-yellow-500 rounded-2xl px-8 py-4 shadow-lg transform rotate-2">
            <p className="text-5xl md:text-7xl font-black text-purple-900">
              DAY 394
            </p>
          </div>
        </div>

        <div className="flex justify-center gap-3">
          <Sparkles className="w-12 h-12 text-yellow-300 animate-spin" style={{ animationDuration: '3s' }} />
          <Sparkles className="w-12 h-12 text-pink-300 animate-spin" style={{ animationDuration: '4s' }} />
          <Sparkles className="w-12 h-12 text-white animate-spin" style={{ animationDuration: '3.5s' }} />
        </div>
      </div>
    </div>
  );
}

export default App;
